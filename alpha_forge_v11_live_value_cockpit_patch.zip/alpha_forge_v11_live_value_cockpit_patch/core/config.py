from __future__ import annotations

from pathlib import Path

RANKING_FILE = Path("ETF_Intelligence_Agent_UPDATED.xlsx")
MASTER_FILE = Path("ETF_Intelligence_Agent_Master_Populated.xlsx")
ALLOCATION_FILE = Path("ETF_Allocation_Model.xlsx")
REPORT_FILE = Path("ETF_Daily_Report.txt")
STATUS_FILE = Path("AUTO_UPDATE_STATUS.json")
DASHBOARD_FILE = Path("index.html")
WATCHLIST_FILE = Path("data/watchlist.csv")
WATCHLIST_OUTPUT_XLSX = Path("AlphaForge_Watchlist.xlsx")
WATCHLIST_OUTPUT_CSV = Path("AlphaForge_Watchlist.csv")
INSIGHTS_OUTPUT_XLSX = Path("AlphaForge_Insights.xlsx")
INSIGHTS_OUTPUT_CSV = Path("AlphaForge_Insights.csv")
ACTION_PLAN_OUTPUT_XLSX = Path("AlphaForge_Action_Plan.xlsx")
ACTION_PLAN_OUTPUT_CSV = Path("AlphaForge_Action_Plan.csv")
PORTFOLIO_TEMPLATE_FILE = Path("data/portfolio_template.csv")

# AlphaForge v7 - Sector Compass
SECTOR_UNIVERSE_FILE = Path("data/sector_universe.csv")
SECTOR_COMPASS_OUTPUT_CSV = Path("AlphaForge_Sector_Compass.csv")
SECTOR_COMPASS_OUTPUT_XLSX = Path("AlphaForge_Sector_Compass.xlsx")
FINECO_PORTFOLIO_TEMPLATE_FILE = Path("data/fineco_portfolio_template.csv")

DEFAULT_ETF_UNIVERSE = [
    {"Ticker": "SWDA.MI", "Nome ETF": "iShares Core MSCI World", "Categoria": "Core", "Tema/Area": "Azionario globale sviluppato"},
    {"Ticker": "VWCE.DE", "Nome ETF": "Vanguard FTSE All-World", "Categoria": "Core", "Tema/Area": "Azionario globale"},
    {"Ticker": "EIMI.MI", "Nome ETF": "iShares Core MSCI EM IMI", "Categoria": "Core", "Tema/Area": "Mercati emergenti"},
    {"Ticker": "SXR8.DE", "Nome ETF": "iShares Core S&P 500", "Categoria": "Core", "Tema/Area": "USA large cap"},
    {"Ticker": "XDEV.MI", "Nome ETF": "Xtrackers MSCI World Value", "Categoria": "Factor", "Tema/Area": "Value globale"},
    {"Ticker": "IWQU.MI", "Nome ETF": "iShares Edge MSCI World Quality", "Categoria": "Factor", "Tema/Area": "Quality globale"},
    {"Ticker": "MVOL.MI", "Nome ETF": "iShares Edge MSCI World Minimum Volatility", "Categoria": "Defensive", "Tema/Area": "Min volatility"},
    {"Ticker": "EUNA.MI", "Nome ETF": "iShares Core Global Aggregate Bond", "Categoria": "Defensive", "Tema/Area": "Obbligazionario globale"},
    {"Ticker": "SGLD.MI", "Nome ETF": "Invesco Physical Gold", "Categoria": "Defensive", "Tema/Area": "Oro"},
    {"Ticker": "EXSA.DE", "Nome ETF": "iShares STOXX Europe 600", "Categoria": "Core", "Tema/Area": "Europa"},
    {"Ticker": "RBOT.MI", "Nome ETF": "iShares Automation & Robotics", "Categoria": "Thematic", "Tema/Area": "Robotica e automazione"},
    {"Ticker": "WCLD.MI", "Nome ETF": "WisdomTree Cloud Computing", "Categoria": "Thematic", "Tema/Area": "Cloud"},
    {"Ticker": "SMH", "Nome ETF": "VanEck Semiconductor", "Categoria": "Thematic", "Tema/Area": "Semiconduttori"},
    {"Ticker": "INRG.MI", "Nome ETF": "iShares Global Clean Energy", "Categoria": "Thematic", "Tema/Area": "Energia pulita"},
]

DEFAULT_MODEL_BASKETS = {
    "AI & Semiconductors": ["NVDA", "AMD", "ASML.AS", "SMH", "STM.MI"],
    "Core ETF": ["SWDA.MI", "VWCE.DE", "SXR8.DE", "EIMI.MI"],
    "Defensive": ["EUNA.MI", "SGLD.MI", "MVOL.MI"],
    "Big Tech": ["AAPL", "MSFT", "GOOGL", "AMZN", "META"],
}

DEFAULT_STOCK_WATCHLIST = [
    {"Ticker": "AAPL", "Nome": "Apple", "Tipo": "Stock", "Area": "USA / Technology"},
    {"Ticker": "MSFT", "Nome": "Microsoft", "Tipo": "Stock", "Area": "USA / Technology"},
    {"Ticker": "NVDA", "Nome": "NVIDIA", "Tipo": "Stock", "Area": "USA / Semiconductors"},
    {"Ticker": "ASML.AS", "Nome": "ASML", "Tipo": "Stock", "Area": "Europe / Semiconductors"},
    {"Ticker": "STM.MI", "Nome": "STMicroelectronics", "Tipo": "Stock", "Area": "Italy / Semiconductors"},
    {"Ticker": "GOOGL", "Nome": "Alphabet", "Tipo": "Stock", "Area": "USA / Internet"},
    {"Ticker": "AMZN", "Nome": "Amazon", "Tipo": "Stock", "Area": "USA / Consumer & Cloud"},
    {"Ticker": "META", "Nome": "Meta Platforms", "Tipo": "Stock", "Area": "USA / Social & AI"},
    {"Ticker": "TSLA", "Nome": "Tesla", "Tipo": "Stock", "Area": "USA / EV"},
]

# AlphaForge v8 - Fineco Portfolio Tracker
FINECO_BASELINE_FILE = Path("data/fineco_portfolio_baseline.csv")
FINECO_TEMPLATE_V8_FILE = Path("data/fineco_portfolio_template_v8.csv")
FINECO_PORTFOLIO_OUTPUT_CSV = Path("AlphaForge_Fineco_Portfolio.csv")
FINECO_PORTFOLIO_OUTPUT_XLSX = Path("AlphaForge_Fineco_Portfolio.xlsx")
FINECO_PORTFOLIO_SUMMARY_FILE = Path("AlphaForge_Fineco_Portfolio_Summary.json")
FINECO_ADVISOR_QUESTIONS_CSV = Path("AlphaForge_Fineco_Advisor_Questions.csv")
FINECO_ADVISOR_QUESTIONS_XLSX = Path("AlphaForge_Fineco_Advisor_Questions.xlsx")

# AlphaForge v9 - News & quasi-real-time fund tracking
FINECO_FUNDS_PUBLIC_FILE = Path("data/fineco_funds_public.csv")
FINECO_FUND_PERFORMANCE_CSV = Path("AlphaForge_Fund_Performance.csv")
FINECO_FUND_PERFORMANCE_XLSX = Path("AlphaForge_Fund_Performance.xlsx")
FINECO_FUND_PRICE_HISTORY_CSV = Path("AlphaForge_Fund_Price_History.csv")
FINECO_FUND_PRICE_HISTORY_XLSX = Path("AlphaForge_Fund_Price_History.xlsx")
FINECO_NEWS_RADAR_CSV = Path("AlphaForge_News_Radar.csv")
FINECO_NEWS_RADAR_XLSX = Path("AlphaForge_News_Radar.xlsx")
FINECO_NEWS_RADAR_SUMMARY = Path("AlphaForge_News_Radar_Summary.json")

# AlphaForge v10 - Fineco decision cockpit
FINECO_ACTUAL_VALUES_FILE = Path("data/fineco_actual_values.csv")
FINECO_DECISION_COCKPIT_CSV = Path("AlphaForge_Fineco_Decision_Cockpit.csv")
FINECO_DECISION_COCKPIT_XLSX = Path("AlphaForge_Fineco_Decision_Cockpit.xlsx")
FINECO_DECISION_SUMMARY_FILE = Path("AlphaForge_Fineco_Decision_Summary.json")

# AlphaForge v11 - Live value cockpit
FINECO_LIVE_PORTFOLIO_CSV = Path("AlphaForge_Live_Portfolio.csv")
FINECO_LIVE_PRICE_HISTORY_CSV = Path("AlphaForge_Live_Price_History.csv")
FINECO_LIVE_SUMMARY_FILE = Path("AlphaForge_Live_Summary.json")
