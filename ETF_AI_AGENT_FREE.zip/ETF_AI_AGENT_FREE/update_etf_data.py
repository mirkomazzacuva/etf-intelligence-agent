"""
ETF Intelligence Agent FREE - V1

Cosa fa:
1. Legge il file Excel con la watchlist ETF.
2. Usa Yahoo Finance/yfinance per scaricare storico prezzi gratuito.
3. Calcola metriche quantitative: performance, volatilita, drawdown, Sharpe, momentum, trend.
4. Calcola uno score 0-100 combinando quant, qualita ETF e tema.
5. Scrive un file Excel aggiornato e un report giornaliero.

Nota: non e consulenza finanziaria. E uno strumento di analisi e monitoraggio.
"""

from __future__ import annotations

import math
from datetime import datetime
from pathlib import Path
from typing import Dict, Optional, Tuple

import numpy as np
import pandas as pd
import yfinance as yf

BASE_DIR = Path(__file__).resolve().parent
INPUT_FILE = BASE_DIR / "ETF_Intelligence_Agent_Master_Populated.xlsx"
OUTPUT_FILE = BASE_DIR / "ETF_Intelligence_Agent_Updated.xlsx"
REPORT_FILE = BASE_DIR / "daily_report.txt"
SHEET_NAME = "ETF_Master"
RISK_FREE_RATE = 0.02  # ipotesi semplice per Sharpe annuo

# Peso modello V1. Lo affineremo dopo i primi risultati.
WEIGHTS = {
    "momentum": 0.20,
    "history_return": 0.15,
    "risk": 0.20,
    "quality": 0.15,
    "theme": 0.15,
    "macro_geo": 0.10,
    "euphoria_penalty": 0.05,
}

THEME_SCORES = {
    "Artificial Intelligence": 88,
    "Semiconductors": 86,
    "Defense": 84,
    "Cybersecurity": 82,
    "Uranium/Nuclear": 78,
    "Robotics": 76,
    "Quality": 74,
    "Momentum": 72,
    "Global Equity": 70,
    "USA Large Cap": 70,
    "Nasdaq / Tech": 70,
    "Gold": 68,
    "Global Bonds": 62,
    "Europe": 60,
    "Emerging Markets": 58,
    "Dividend": 58,
    "Quality Dividend": 60,
    "Value": 58,
    "Low Volatility": 64,
}

MACRO_GEO_SCORES = {
    "Artificial Intelligence": 78,
    "Semiconductors": 74,
    "Defense": 86,
    "Cybersecurity": 80,
    "Uranium/Nuclear": 76,
    "Gold": 76,
    "Global Bonds": 62,
    "Global Equity": 68,
    "USA Large Cap": 68,
    "Nasdaq / Tech": 66,
    "Europe": 60,
    "Emerging Markets": 55,
}

EUPHORIA_PENALTY = {
    "Artificial Intelligence": 10,
    "Semiconductors": 12,
    "Nasdaq / Tech": 8,
    "Uranium/Nuclear": 7,
    "Robotics": 6,
}


def clean_ter(value) -> Optional[float]:
    if pd.isna(value):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).replace("%", "").replace(",", ".").strip()
    try:
        return float(text) / 100 if float(text) > 1 else float(text)
    except ValueError:
        return None


def yahoo_candidates(ticker: str) -> list[str]:
    ticker = str(ticker).strip()
    candidates = [ticker]
    if not ticker.endswith(".MI"):
        candidates.append(f"{ticker}.MI")
    if not ticker.endswith(".DE"):
        candidates.append(f"{ticker}.DE")
    if not ticker.endswith(".AS"):
        candidates.append(f"{ticker}.AS")
    return list(dict.fromkeys(candidates))


def download_prices(ticker: str) -> Tuple[Optional[pd.Series], Optional[str], Optional[str]]:
    for candidate in yahoo_candidates(ticker):
        try:
            data = yf.download(candidate, period="5y", auto_adjust=True, progress=False, threads=False)
            if data is not None and not data.empty and "Close" in data.columns:
                close = data["Close"].dropna()
                if len(close) > 30:
                    return close, candidate, None
        except Exception as exc:
            last_error = str(exc)
    return None, None, last_error if "last_error" in locals() else "No data"


def annualized_return(prices: pd.Series) -> Optional[float]:
    if prices is None or len(prices) < 2:
        return None
    years = (prices.index[-1] - prices.index[0]).days / 365.25
    if years <= 0:
        return None
    return (prices.iloc[-1] / prices.iloc[0]) ** (1 / years) - 1


def period_return(prices: pd.Series, trading_days: int) -> Optional[float]:
    if prices is None or len(prices) < trading_days + 1:
        return None
    return prices.iloc[-1] / prices.iloc[-trading_days] - 1


def volatility(prices: pd.Series) -> Optional[float]:
    returns = prices.pct_change().dropna()
    if len(returns) < 20:
        return None
    return returns.std() * math.sqrt(252)


def max_drawdown(prices: pd.Series) -> Optional[float]:
    if prices is None or prices.empty:
        return None
    cumulative_max = prices.cummax()
    drawdowns = prices / cumulative_max - 1
    return drawdowns.min()


def sharpe_ratio(prices: pd.Series) -> Optional[float]:
    cagr = annualized_return(prices)
    vol = volatility(prices)
    if cagr is None or vol is None or vol == 0:
        return None
    return (cagr - RISK_FREE_RATE) / vol


def moving_average_trend(prices: pd.Series) -> Optional[str]:
    if len(prices) < 200:
        return None
    ma200 = prices.rolling(200).mean().iloc[-1]
    last = prices.iloc[-1]
    return "Positive" if last > ma200 else "Negative"


def score_between(value, low, high, inverse=False) -> float:
    if value is None or pd.isna(value):
        return 50.0
    value = max(min(float(value), high), low)
    score = 100 * (value - low) / (high - low)
    return 100 - score if inverse else score


def history_weight(days: int) -> float:
    years = days / 365.25
    if years >= 5:
        return 1.0
    if years >= 3:
        return 0.8
    if years >= 1:
        return 0.6
    if years >= 0.5:
        return 0.4
    return 0.2


def status_from_score(score: float) -> str:
    if score >= 78:
        return "Buy Watchlist"
    if score >= 68:
        return "Accumulate Carefully"
    if score >= 55:
        return "Hold / Monitor"
    if score >= 45:
        return "Speculative Only"
    return "Avoid for Now"


def calculate_row(row: pd.Series) -> Dict[str, object]:
    ticker = row.get("Yahoo Ticker") or row.get("Ticker")
    prices, used_ticker, error = download_prices(str(ticker))

    result = {
        "Yahoo Ticker Used": used_ticker,
        "Data Status": "OK" if prices is not None else f"ERROR: {error}",
    }

    if prices is None:
        result.update({
            "Last Price": None,
            "Perf 1M": None,
            "Perf 3M": None,
            "Perf 6M": None,
            "Perf 12M": None,
            "CAGR Available History": None,
            "Volatility Ann.": None,
            "Max Drawdown": None,
            "Sharpe": None,
            "MA200 Trend": None,
            "Final Score": None,
            "Decision Status": "Data Missing",
            "Comment": "Ticker non trovato su Yahoo Finance. Verificare Yahoo Ticker manualmente.",
        })
        return result

    days = (prices.index[-1] - prices.index[0]).days
    hist_weight = history_weight(days)
    cagr = annualized_return(prices)
    vol = volatility(prices)
    mdd = max_drawdown(prices)
    sharpe = sharpe_ratio(prices)
    perf_6m = period_return(prices, 126)
    perf_12m = period_return(prices, 252)
    trend = moving_average_trend(prices)

    momentum_raw = np.nanmean([
        score_between(perf_6m, -0.20, 0.40),
        score_between(perf_12m, -0.30, 0.70),
        75 if trend == "Positive" else 35,
    ])
    history_raw = score_between(cagr, -0.05, 0.25) * hist_weight + 50 * (1 - hist_weight)
    risk_raw = np.nanmean([
        score_between(vol, 0.05, 0.45, inverse=True),
        score_between(abs(mdd) if mdd is not None else None, 0.05, 0.60, inverse=True),
        score_between(sharpe, -0.5, 1.8),
    ])

    ter = clean_ter(row.get("TER"))
    ter_score = score_between(ter, 0.0005, 0.008, inverse=True) if ter is not None else 55
    quality_raw = ter_score

    theme = row.get("Theme")
    theme_raw = THEME_SCORES.get(str(theme), 60)
    macro_raw = MACRO_GEO_SCORES.get(str(theme), 60)
    penalty = EUPHORIA_PENALTY.get(str(theme), 0)

    final_score = (
        WEIGHTS["momentum"] * momentum_raw
        + WEIGHTS["history_return"] * history_raw
        + WEIGHTS["risk"] * risk_raw
        + WEIGHTS["quality"] * quality_raw
        + WEIGHTS["theme"] * theme_raw
        + WEIGHTS["macro_geo"] * macro_raw
        - WEIGHTS["euphoria_penalty"] * penalty
    )

    result.update({
        "Last Price": float(prices.iloc[-1]),
        "Perf 1M": period_return(prices, 21),
        "Perf 3M": period_return(prices, 63),
        "Perf 6M": perf_6m,
        "Perf 12M": perf_12m,
        "CAGR Available History": cagr,
        "Volatility Ann.": vol,
        "Max Drawdown": mdd,
        "Sharpe": sharpe,
        "MA200 Trend": trend,
        "History Weight": hist_weight,
        "Momentum Score": momentum_raw,
        "Risk Score": risk_raw,
        "Theme Score": theme_raw,
        "Macro/Geo Score": macro_raw,
        "Euphoria Penalty": penalty,
        "Final Score": round(float(final_score), 1),
        "Decision Status": status_from_score(final_score),
        "Comment": build_comment(row, final_score, trend, penalty),
    })
    return result


def build_comment(row: pd.Series, score: float, trend: Optional[str], penalty: float) -> str:
    theme = row.get("Theme", "")
    status = status_from_score(score)
    comment = f"{status}. Tema: {theme}. Trend MA200: {trend or 'non disponibile'}."
    if penalty > 0:
        comment += " Attenzione: tema potenzialmente affollato/euforico, usare come satellite."
    if score >= 78:
        comment += " Da monitorare con priorita, mantenendo disciplina sul rischio."
    elif score < 55:
        comment += " Non prioritario finche trend/rischio non migliorano."
    return comment


def generate_report(df: pd.DataFrame) -> str:
    today = datetime.now().strftime("%Y-%m-%d %H:%M")
    ok = df[df["Final Score"].notna()].copy()
    ok = ok.sort_values("Final Score", ascending=False)
    top = ok.head(10)
    weak = ok.tail(5).sort_values("Final Score")

    lines = []
    lines.append(f"ETF Intelligence Agent - Daily Report ({today})")
    lines.append("")
    lines.append("Nota: questo report e' uno strumento di analisi, non consulenza finanziaria personalizzata.")
    lines.append("")
    lines.append("TOP 10 ETF")
    for _, r in top.iterrows():
        lines.append(f"- {r.get('Ticker')} | {r.get('ETF Name')} | Score {r.get('Final Score')} | {r.get('Decision Status')}")
    lines.append("")
    lines.append("ETF PIU' DEBOLI DA MONITORARE")
    for _, r in weak.iterrows():
        lines.append(f"- {r.get('Ticker')} | {r.get('ETF Name')} | Score {r.get('Final Score')} | {r.get('Decision Status')}")
    lines.append("")
    lines.append("WARNING GENERALE")
    lines.append("- ETF tematici come AI, semiconduttori, Nasdaq e uranio possono avere trend forti ma anche rischio di concentrazione/euforia.")
    lines.append("- Usa la classifica come shortlist ragionata, non come ordine automatico di acquisto.")
    return "\n".join(lines)


def main() -> None:
    if not INPUT_FILE.exists():
        raise FileNotFoundError(f"File non trovato: {INPUT_FILE}")

    df = pd.read_excel(INPUT_FILE, sheet_name=SHEET_NAME)
    if "Yahoo Ticker" not in df.columns:
        df["Yahoo Ticker"] = df["Ticker"]

    print(f"Aggiorno {len(df)} ETF...")
    results = []
    for i, row in df.iterrows():
        print(f"[{i + 1}/{len(df)}] {row.get('Ticker')} - {row.get('ETF Name')}")
        results.append(calculate_row(row))

    results_df = pd.DataFrame(results)

    # Rimuove eventuali vecchie colonne calcolate e le ricrea aggiornate.
    calc_cols = list(results_df.columns)
    base_df = df.drop(columns=[c for c in calc_cols if c in df.columns], errors="ignore")
    out = pd.concat([base_df, results_df], axis=1)
    out = out.sort_values("Final Score", ascending=False, na_position="last")

    with pd.ExcelWriter(OUTPUT_FILE, engine="openpyxl") as writer:
        out.to_excel(writer, sheet_name="ETF_Master_Updated", index=False)
        pd.DataFrame([WEIGHTS]).to_excel(writer, sheet_name="Scoring_Weights", index=False)

    report = generate_report(out)
    REPORT_FILE.write_text(report, encoding="utf-8")
    print("\nCompletato.")
    print(f"Excel aggiornato: {OUTPUT_FILE}")
    print(f"Report: {REPORT_FILE}")


if __name__ == "__main__":
    main()
