# ETF Intelligence Agent FREE

Questo progetto aggiorna gratuitamente il database ETF usando dati pubblici Yahoo Finance tramite `yfinance`.

## 1. Installazione

Apri il terminale nella cartella del progetto e lancia:

```bash
pip install -r requirements.txt
```

## 2. Avvio

```bash
python update_etf_data.py
```

## 3. Output

Lo script crea:

- `ETF_Intelligence_Agent_Updated.xlsx`: database aggiornato
- `daily_report.txt`: report giornaliero sintetico

## 4. Note importanti

- I dati sono gratuiti e possono avere limiti o ticker mancanti.
- Il report non è consulenza finanziaria personalizzata.
- Se un ticker non viene trovato, modifica la colonna `Yahoo Ticker` nel file Excel.
- Per ETF quotati a Milano spesso il suffisso è `.MI`, ma non sempre Yahoo Finance lo gestisce correttamente.
