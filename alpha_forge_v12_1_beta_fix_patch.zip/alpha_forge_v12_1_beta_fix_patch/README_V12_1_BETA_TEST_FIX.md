# AlphaForge v12.1 - Correzione beta test con NAV aggiornati

## Problema
Il beta tester v12 aveva due test basati sulla fotografia Fineco del 29/10/2026:
- pretendeva che la cronologia NAV contenesse sempre esattamente 14 righe;
- pretendeva che la dashboard mostrasse sempre il controvalore originale 25.735,13 EUR e il margine +88,93 EUR.

Quando l'app ha correttamente acquisito NAV piu recenti, entrambi i test sono diventati falsi pur essendo regolare l'aggiornamento dei valori.

## Correzione
Modificato solo `tests/test_real_fineco.py`:
- il test della fotografia Fineco rimane ancorato ai dati originali e li verifica separatamente;
- il test del portafoglio aggiornato verifica che contovalore, costo e margine siano matematicamente riconciliati;
- il test HTML confronta i valori con l'ultimo file JSON generato anziche con una cifra storica;
- i test di fonte NAV vecchia/nuova sono isolati dalla cronologia incrementale;
- nessun valore reale, transazione, NAV o dashboard viene sovrascritto dalla patch.

## Installazione (GitHub via browser)
1. Caricare lo ZIP **senza estrarlo** nella cartella principale del repository.
2. Actions > AlphaForge Patch Installer > Run workflow.
3. Inserire `patch_zip = alpha_forge_v12_1_beta_fix_patch.zip`.
4. Impostare `run_beta_test = true`, `run_full_update = true`, `remove_patch_zip = true`.
5. Verificare il risultato verde e che il report mostri 7 test v12 superati.

## Test locale
Testata sui dati base v12 e su una cronologia arricchita di nuovi NAV simulati (7 test OK in entrambi i casi).
