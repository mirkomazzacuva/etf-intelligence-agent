"""Stable checks for Fineco v12.

Historical snapshot tests are isolated from new genuine NAVs and PAC trades.
The published dashboard test checks the latest generated data, not the old
29/10/2026 snapshot as if it were still today's quote.
"""
from contextlib import contextmanager
from datetime import date, timedelta
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

from core import fineco_real_engine as engine
from core.fineco_nav_sources import NAVReading, parse_borsa_fidelity, parse_fam_page
from core.fineco_real_ui import render_real_dashboard


@contextmanager
def original_snapshot_only():
    """Freeze initial Fineco positions, ignoring later saved NAVs and trades."""
    positions = engine.load_positions()
    cutoffs = {p['ISIN']: p['Data_rilevazione'] for p in positions}
    history = [
        h for h in engine.load_nav_history()
        if h['ISIN'] in cutoffs and h['Data_NAV'] <= cutoffs[h['ISIN']]
    ]
    with patch.object(engine, 'load_nav_history', return_value=history), \
         patch.object(engine, '_manual_quotes', return_value=[]), \
         patch.object(engine, '_confirmed_purchases', return_value={}):
        yield


class RealPortfolioTests(unittest.TestCase):
    def test_original_fineco_snapshot_reconciliation(self):
        positions = engine.load_positions()
        expected_market = round(sum(engine._money(p['Controvalore_Fineco_EUR']) for p in positions), 2)
        expected_gain = round(sum(engine._money(p['Margine_Fineco_EUR']) for p in positions), 2)
        expected_basis = round(expected_market - expected_gain, 2)
        expected_pac = round(sum(engine._money(p.get('PAC_programmato_mensile_EUR', 0)) for p in positions), 2)
        with original_snapshot_only():
            rows, history, summary, _ = engine.build_real_portfolio(allow_network=False, persist=False)
        self.assertEqual(len(rows), len(positions))
        self.assertGreaterEqual(len(history), len(positions))
        self.assertEqual(summary['market_value_eur'], expected_market)
        self.assertEqual(summary['cost_basis_eur'], expected_basis)
        self.assertEqual(summary['margin_eur'], expected_gain)
        self.assertEqual(summary['pac_monthly_eur'], expected_pac)
        self.assertAlmostEqual(sum(r['Margine_EUR'] for r in rows), expected_gain, places=2)
        self.assertTrue(all(r['Fonte_ultimo_dato'] == 'Schermata Fineco' for r in rows))
        # Fixed reconciliation of the user's screenshot remains an invariant.
        if len(positions) == 7 and all(p['Data_rilevazione'] == '2026-10-29' for p in positions):
            self.assertEqual((expected_market, expected_basis, expected_gain),
                             (25735.13, 25646.20, 88.93))
            self.assertEqual(expected_pac, 300.0)
            self.assertEqual(summary['positive_count'], 4)
            self.assertEqual(summary['negative_count'], 3)

    def test_current_nav_history_is_not_confused_with_snapshot(self):
        rows, history, summary, _ = engine.build_real_portfolio(allow_network=False, persist=False)
        self.assertEqual(len(rows), 7)
        self.assertGreaterEqual(len(history), 7)
        self.assertEqual(round(sum(r['Controvalore_EUR'] for r in rows), 2), summary['market_value_eur'])
        self.assertEqual(round(sum(r['Costo_carico_EUR'] for r in rows), 2), summary['cost_basis_eur'])
        self.assertEqual(round(sum(r['Margine_EUR'] for r in rows), 2), summary['margin_eur'])
        self.assertTrue(all(r['NAV_attuale_EUR'] > 0 for r in rows))
        self.assertTrue(all(r['Fonte_ultimo_dato'] for r in rows))

    def test_fam_parser_with_isin_and_date(self):
        html = ('<html><body>ISIN IE000DWG3DP6 NAV Price 163.889 1 Day % 0.0666 '
                'YTD % 14.8 NAV Date 2026-10-07 NAV Currency EUR</body></html>')
        nav = parse_fam_page('IE000DWG3DP6', html, 'https://sample.test')
        self.assertIsNotNone(nav)
        self.assertEqual(nav.nav_date, date(2026, 10, 7))
        self.assertEqual(nav.nav_eur, 163.889)
        self.assertIsNone(parse_fam_page('IE000KTYLDC4', html, 'https://sample.test'))

    def test_borsa_parser(self):
        html = ('<html><body>Fidelity Euro 50 Index A Cap Eur 28,67 +0,30% '
                'Valuta: EUR Data: 28/10/26 Andamento Ultima Precedente '
                'Valuta Data Variazione Isin LU0261952682</body></html>')
        result = parse_borsa_fidelity('LU0261952682', html, 'https://borsa.test')
        self.assertIsNotNone(result)
        self.assertEqual(result.nav_eur, 28.67)
        self.assertEqual(result.nav_date, date(2026, 10, 28))

    def test_older_public_nav_cannot_override_fineco(self):
        positions = engine.load_positions()
        p = next(p for p in positions if p['ISIN'] == 'IE000DWG3DP6')
        old_day = date.fromisoformat(p['Data_rilevazione']) - timedelta(days=30)
        quote = NAVReading(p['ISIN'], old_day, 159.289, 'Issuer', 'https://issuer.test')
        with original_snapshot_only(), patch.object(engine, 'fetch_verified_nav', return_value=(quote, 'OK')):
            rows, _, _, _ = engine.build_real_portfolio(allow_network=True, persist=False)
        fund = next(r for r in rows if r['ISIN'] == p['ISIN'])
        self.assertEqual(fund['Controvalore_EUR'], engine._money(p['Controvalore_Fineco_EUR']))
        self.assertEqual(fund['Margine_EUR'], engine._money(p['Margine_Fineco_EUR']))

    def test_new_nav_updates_only_matching_fund(self):
        positions = engine.load_positions()
        p = next(p for p in positions if p['ISIN'] == 'IE000DWG3DP6')
        new_day = date.fromisoformat(p['Data_rilevazione']) + timedelta(days=1)
        new_nav = round(engine._money(p['NAV_rilevato_EUR']) * 1.001, 6)
        quote = NAVReading(p['ISIN'], new_day, new_nav, 'Issuer', 'https://issuer.test')

        def fake_fetch(isin):
            return (quote, 'OK') if isin == p['ISIN'] else (None, 'offline')

        with original_snapshot_only(), patch.object(engine, 'fetch_verified_nav', side_effect=fake_fetch):
            rows, history, _, _ = engine.build_real_portfolio(allow_network=True, persist=False)
        changed = next(r for r in rows if r['ISIN'] == p['ISIN'])
        unchanged = next(r for r in rows if r['ISIN'] == 'IE000KTYLDC4')
        expected_value = round(engine._money(p['Controvalore_Fineco_EUR']) * new_nav /
                               engine._money(p['NAV_rilevato_EUR']), 2)
        self.assertAlmostEqual(changed['Controvalore_EUR'], expected_value, places=2)
        self.assertEqual(changed['Fonte_ultimo_dato'], 'Issuer')
        self.assertEqual(unchanged['Fonte_ultimo_dato'], 'Schermata Fineco')
        self.assertIn(new_day.isoformat(), [h['Data_NAV'] for h in history if h['ISIN'] == p['ISIN']])

    def test_public_dashboard_shows_latest_generated_real_data(self):
        dashboard_file = engine.OUT_DASH_DATA
        self.assertTrue(dashboard_file.is_file(), 'Eseguire generate_real_portfolio.py prima del test')
        summary = json.loads(dashboard_file.read_text(encoding='utf-8'))['summary']
        with TemporaryDirectory() as td:
            output = Path(td) / 'test.html'
            render_real_dashboard(output)
            html = output.read_text(encoding='utf-8')
            def it_format(number):
                return f'{float(number):,.2f}'.replace(',', '#').replace('.', ',').replace('#', '.')
            for value in ('market_value_eur', 'cost_basis_eur', 'margin_eur'):
                self.assertIn(it_format(summary[value]), html)
            self.assertIn('AlphaForge v12', html)
            self.assertIn('Fineco', html)
            self.assertEqual(html.count("<article class='fund-card'"), 7)
            for p in engine.load_positions():
                self.assertIn(p['ISIN'], html)


if __name__ == '__main__':
    unittest.main()
